package persistencia;


import modelo.Estudiante;
import modelo.Persona;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;

public class DaoEstudianteJson {

    private final String fileLocation;
    // Lista de estudiantes que actuará como "documento" en memoria
    private List<Estudiante> estudiantes;
    private final Gson gson;

    public DaoEstudianteJson() {
        this.fileLocation = "src//archivosJson//estudiantes.json";
        this.gson = new Gson(); //convertir JSON a objetos de Java
        // Se intenta cargar la lista de estudiantes desde el archivo JSON 
        try (FileReader reader = new FileReader(fileLocation)) {
            Type listType = new TypeToken<List<Estudiante>>() {}.getType(); //Crea un objeto Type que representa el tipo genérico List<Estudiante>. Esto es necesario porque Gson requiere el tipo exacto para deserializar listas (debido a la borradura de tipos en Java).
            this.estudiantes = gson.fromJson(reader, listType);//Usa Gson para leer el JSON del archivo y convertirlo en una List<Estudiante>. Asigna el resultado a this.estudiantes (una variable de instancia, probablemente declarada como List<Estudiante>).
            if (this.estudiantes == null) {
                this.estudiantes = new ArrayList<>();
            }
        } catch (IOException e) {
            System.err.println("Error al cargar o parsear el archivo JSON: " + e.getMessage());
            // Si ocurre un error, se inicializa la lista como vacía, se crea el archivo JSONvacío
            // modifica esta parte del código para que no se aparezca por la cónsola
            // y desarrolla lo necesario para cuando empieces todo de cero. El ejemplo te lo coloco 
            // con un solo registro a fin de que se ejecute normalmente con el archivo JSON pero
            // como te indiqué al hacerlo desde cero el programa crea el archivo vacío y desde el mismo
            // programa puedes añadir los registros.
            this.estudiantes = new ArrayList<>();
        }
    }

    private boolean updateDocument() {
        try (FileWriter writer = new FileWriter(fileLocation)) {
            gson.toJson(estudiantes, writer);
            return true;
        } catch (IOException e) {
            System.err.println("Error al guardar el archivo JSON: " + e.getMessage());
            return false;
        }
    }

     public boolean agregarPersona(Persona nEstudiante) {
        estudiantes.add((Estudiante) nEstudiante);//Añade el objeto nEstudiante a la lista estudiantes. Hace un cast explícito a Estudiante, asumiendo que Persona es una superclase o interfaz compatible (por ejemplo, Estudiante extiende Persona). Si el cast falla (tipo incompatible), lanza una ClassCastException en tiempo de ejecución.
        return updateDocument();
    }

    private Estudiante buscarElementoPorCedula(Integer cedula) {
        for (Estudiante estudiante : estudiantes) {
            if (estudiante.getCedula() == cedula) {
                return estudiante;
            }
        }
        return null;
    }

    public Estudiante buscarPersona(Integer cedula) {
        return buscarElementoPorCedula(cedula);
    }

   public boolean actualizarPersona(Persona nEstudiante) {
        Estudiante estudianteEncontrado = buscarElementoPorCedula(nEstudiante.getCedula());
        if (estudianteEncontrado != null) {
            Estudiante est = (Estudiante) nEstudiante;
            estudianteEncontrado.setNomApe(est.getNomApe());
            estudianteEncontrado.setEficiencia(est.getEficiencia());
            return updateDocument();
        }
        return false;
    }

    public boolean borrarPersona(Integer cedula) {
        Estudiante estudianteEncontrado = buscarElementoPorCedula(cedula);
        if (estudianteEncontrado != null) {
            estudiantes.remove(estudianteEncontrado);
            return updateDocument();
        }
        return false;
    }

    public ArrayList<Estudiante> todosLosEstudiantes() {
        return new ArrayList<>(estudiantes);
    }
}