
package controller;

import modelo.Estudiante;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JTable;
import static javax.swing.WindowConstants.DO_NOTHING_ON_CLOSE;
import javax.swing.table.DefaultTableModel;
import persistencia.DaoEstudianteJson;

public class Controladora {

  JFrame ventana;
  JTable tablaEstudiantes;
  JButton botonAgregar,botonModificar,botonEliminar,botonSalvar,botonListaEstudiantes;
  JTextField txtCedula;
  DaoEstudianteJson datosEst;
  
 public Controladora(JFrame ventana,JButton botonAgregar,JButton botonModificar,JButton botonEliminar, JButton botonSalvar, JButton botonListaEstudiantes, JTextField txtCedula,DaoEstudianteJson datosEst ){
        this.ventana = ventana;
        this.botonAgregar = botonAgregar;
        this.botonModificar = botonModificar ;
        this.botonEliminar = botonEliminar;
        this.botonSalvar = botonSalvar ;
        this.botonListaEstudiantes = botonListaEstudiantes;
        this.txtCedula = txtCedula;
        this.datosEst = datosEst;
     }
 
 public Controladora(JFrame ventana,JTable tablaEstudiantes){
    this.ventana = ventana;
    this.tablaEstudiantes=tablaEstudiantes;
    
 }

 public Controladora(JFrame ventana, DaoEstudianteJson datosEst) {
       this.ventana = ventana;
       
    }
 
  public void iniciaVentana()
 {
         ventana.setLocationRelativeTo(null);
         ventana.setIconImage(new ImageIcon("src/imagenes/stuIconN.png").getImage());
         ventana.setResizable(false);
         ventana.setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
         txtCedula.requestFocus();
         botonSalvar.setVisible(false);
 }
 
public void iniciaVentana(int i)
 {
         ventana.setLocationRelativeTo(null);
         ventana.setIconImage(new ImageIcon("src/imagenes/stuIconN.png").getImage());
         ventana.setResizable(false);
         ventana.setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
         
 } 
    
 public  void limpia(JTextField txtCedula,JTextField txtNombres, JTextField txtEficiencia) {
        txtCedula.setText("");
        txtNombres.setText("");
        txtEficiencia.setText("");
        txtCedula.requestFocus();
    } 

public  void activar_desactivar(boolean verdadFalso,JButton botonAgregar,JButton botonModificar,JButton botonEliminar, JButton botonListaEstudiantes, JButton botonSalvar, JTextField txtCedula)
     {  botonAgregar.setEnabled(verdadFalso);
        botonModificar.setEnabled(verdadFalso);
        botonEliminar.setEnabled(verdadFalso);
        botonListaEstudiantes.setEnabled(verdadFalso);
        botonSalvar.setVisible(!verdadFalso);
        txtCedula.setEnabled(verdadFalso);
    }

public void llenarTabla(DaoEstudianteJson datosEst){

        String[] columna = { "Cédula", "Nombre y Apellido", "Eficiencia" };
            DefaultTableModel dtm = new DefaultTableModel(null,columna);
            ArrayList<Estudiante> Lista= datosEst.todosLosEstudiantes();
            for (Estudiante est : Lista)
            {
                String[] row = {Long.toString(est.getCedula()), est.getNomApe(),Float.toString(est.getEficiencia()) };
                dtm.addRow(row);
            }
            tablaEstudiantes.setModel(dtm);
    }

public void validaLetra(java.awt.event.KeyEvent evt){
    int k=(int)evt.getKeyChar();//Transforma los caracteres del TextField en su codigo ASCI
       if ((k < 97 || k > 122) && (k<65 || k>90) && k!=20 && k!=8 && k!=32 && k!=127)//codigo ASCI
       {
          evt.setKeyChar((char)KeyEvent.VK_CLEAR);//anula a entrada de caracteres no indicados(solo permito mayusculas minusculas, espacios e ir para atras
          JOptionPane.showMessageDialog(null,"Sólo debe ingresar letras","Error Datos",JOptionPane.ERROR_MESSAGE);
       }
}
 public  int validarVacio (JTextField campo, String mensaje){
       if (campo.getText().isEmpty())
          { JOptionPane.showMessageDialog(null, mensaje, "Error falta un dato", JOptionPane.ERROR_MESSAGE); 
            return 0; 
          }
       else
            return 1;
   }  
 
 public int validarEntero (String numero, String mensaje){
   try{
         int numero1 = Integer.parseInt(numero);
         return 1; 
      }
   catch(NumberFormatException ex){
      JOptionPane.showMessageDialog(null,mensaje,"Debe indicar un numero entero", JOptionPane.ERROR_MESSAGE);
      return 0;
       }
}
 
 public int validarRango(float numero,String mensaje)
   {
      if (numero < 0 || numero > 1)
        {JOptionPane.showMessageDialog(null,mensaje,"Rango no permitido", JOptionPane.ERROR_MESSAGE);
         return 0;
        }
      else
        return 1;   
   }
 
 public int validarReal (String numero, String mensaje)
  {
    try{
       float numero1 = Float.parseFloat(numero); 
       return validarRango(numero1,"Eficiencia debe estar entre 0 y 1");
       
      }
   catch(NumberFormatException ex){
    JOptionPane.showMessageDialog(null,mensaje,"Tipo De Dato No es un Real", JOptionPane.ERROR_MESSAGE);
    return 0;
     }
    
 }
 
 public void tomarFoco(JTextField cajaTexto)
 {
     cajaTexto.requestFocus();
 }  
 
 public void traerDatos(Estudiante est, JTextField txtNombres, JTextField txtEficiencia ){
   
    txtNombres.setText(est.getNomApe());
    txtEficiencia.setText(String.valueOf(est.getEficiencia()));
   
 }
 
 public void agregarEstudiante(JTextField txtCedula,JTextField txtNombres, JTextField txtEficiencia){
     if (validarVacio(txtCedula,"Debe indicar la cédula del estudiante")==1 && validarEntero(txtCedula.getText(), "Cédula no es numérica") == 1 && validarVacio(txtNombres,"Debe indicar el nombre del estudiante") == 1 && validarVacio(txtEficiencia,"Debe indicar la eficiencia del estudiante")==1 && validarReal(txtEficiencia.getText(), "Eficiencia no posee el formato apropiado #.##")==1)
         {     Estudiante est = datosEst.buscarPersona(Integer.valueOf(txtCedula.getText()));
                if (est != null)
                    JOptionPane.showMessageDialog(null, "Estudiante ya está registrado ", "Error al Registrar", JOptionPane.ERROR_MESSAGE);
                else { 
                       Estudiante Estud = new Estudiante(Integer.parseInt(txtCedula.getText()), txtNombres.getText(), Float.valueOf(txtEficiencia.getText()));
                       boolean resultado = datosEst.agregarPersona(Estud);
                        if (resultado == true) {
                           JOptionPane.showMessageDialog(null, "Estudiante " + txtNombres.getText(), " agregado con exito!", JOptionPane.INFORMATION_MESSAGE);
                           limpia(txtCedula, txtNombres, txtEficiencia);
                       } else 
                           JOptionPane.showMessageDialog(null, "Operacion Fallida, no se agregó Estudiante", "Error", JOptionPane.ERROR_MESSAGE);
                       
                     } 
            
         }
     
 }
 
 public void modificarEstudiante(JTextField txtCedula,JTextField txtNombres, JTextField txtEficiencia, DaoEstudianteJson datosEst){
     if (validarVacio(txtCedula, "Debe indicar la Cédula que desea modificar")==1 && validarEntero(txtCedula.getText(), "Cédula no es numérica")==1)
        { 
            Estudiante est = datosEst.buscarPersona(Integer.valueOf(txtCedula.getText()));
                if (est == null) {
                    JOptionPane.showMessageDialog(null, "Estudiante no Existe", "Error cédula no encontrada", JOptionPane.ERROR_MESSAGE);
                } else {
                    traerDatos(est, txtNombres, txtEficiencia);
                    activar_desactivar(false, botonAgregar, botonModificar, botonEliminar, botonListaEstudiantes, botonSalvar, txtCedula);
                }
        } 
 }
 
 public void salvarPersona(DaoEstudianteJson datosEst,JTextField txtCedula,JTextField txtNombres, JTextField txtEficiencia){
     
     Estudiante est = datosEst.buscarPersona(Integer.valueOf(txtCedula.getText()));
                est.setNomApe(txtNombres.getText());
                est.setEficiencia(Float.valueOf(txtEficiencia.getText()));
                datosEst.actualizarPersona(est);
 } 
 
 public void eliminarEstudiante(JTextField txtCedula,JTextField txtNombres, JTextField txtEficiencia, DaoEstudianteJson datosEst){
     if  (validarVacio(txtCedula, "Debe indicar la Cédula que desea eliminar")==1 && validarEntero(txtCedula.getText(), "Cédula no es numérica")==1 )
           {   
                   Estudiante est = datosEst.buscarPersona(Integer.valueOf(txtCedula.getText()));
                    if (est == null) {
                        JOptionPane.showMessageDialog(null, "Estudiante no Existe", "Error cédula no encontrada", JOptionPane.ERROR_MESSAGE);
                    }
                    else
                    {
                         traerDatos(est, txtNombres, txtEficiencia);
                         int confirmacion = JOptionPane.showOptionDialog(null, "¿Desea Realizar La Operación?", "::::...Confirmación...:::",
                            JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE, null, null, null);
                         if (confirmacion == 0){
                            datosEst.borrarPersona(Integer.valueOf(txtCedula.getText()));
                         }
                    limpia(txtCedula, txtNombres, txtEficiencia);
                   }
           }
 }
 
 public void activaVentana(JFrame ventana, JFrame ventana2){
     ventana.setLocationRelativeTo(null);
     ventana.setVisible(true);
     ventana2.dispose();
     
}
 
 
}

